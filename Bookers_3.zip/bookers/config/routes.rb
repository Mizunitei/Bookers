Rails.application.routes.draw do
 root to: 'homes#top'
  resources :books



#なんでルーティングこれだけでいいの
#get 'top' => 'homes#top'⇒root to: 'homes#top'との違いわからない

# For details on the DSL available within this file, see http://guides.rubyonrails.org/routing.html

#root "books#inde

 post 'books/:id' => 'books#show'

 post 'books/:id/edit' => 'books#edit'


 patch 'books/:id' => 'books#update'
 
 delete 'books/:id' => 'books#destroy', as: 'destroy_book'

end