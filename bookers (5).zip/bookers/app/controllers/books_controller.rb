class BooksController < ApplicationController


  def index

    @books=Book.all#一覧表示用
    @book=Book.new

    if params[:id].present?
     set_book
    else
    @book = Book.new
    end

  end


  #def new
   #@book=Book.new
  #end

 def create

    # １. データを新規登録するためのインスタンス作成

    # ２. データをデータベースに保存するためのsaveメソッド実行
    @book = Book.new(book_params)
   if @book.save
    flash[:notice]="successfully"
    redirect_to book_path(@book.id)

   else

    flash.now[:notice]="error"
    @books=Book.all  
    render :index
   end



 # respond_to do |format|
    #if @book.save
     #format.html { redirect_to  books_path, notice: 'Book was successfully created.' }
     # format.json { render :show, status: :created, location: @book }
    #else
     # format.html { render :new }
      #format.json { render json: @book.errors, status: :unprocessable_entity }
    #end
 #end
 end

 def show
    @book= Book.find(params[:id]) #idに合致した値をとってきてほしい

 end


 def show
    @book= Book.find(params[:id]) #idに合致した値をとってきてほしい

 end


  def edit
    @book =Book.find(params[:id])
  end



   def update
     book = Book.find(params[:id])
    book.update(book_params)
     redirect_to book_path(book.id)



def destroy
end





   #respond_to do |format|
   # if @book.update(book_params)
      #format.html { redirect_to request.referer, notice: 'Book was successfully updated.' }
      #format.json { render :show, status: :ok, location: @Book }
   # else
      #format.html { render :edit }
      #format.json { render json: @book.errors, status: :unprocessable_entity }
   # end

  #end

   end

   def destroy
    book = Book.find(params[:id])
  	book.destroy
  	redirect_to books_path
   end






 private
  # ストロングパラメータ
  def book_params
    params.require(:book).permit(:title, :body)
  end













end

